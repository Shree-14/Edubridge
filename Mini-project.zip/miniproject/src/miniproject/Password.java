package miniproject;

import java.util.Random;
import java.util.Scanner;

public class Password
{
	public static String generatePassword(int length) 
	{
		Scanner word = new Scanner(System.in);
		String lower_Character = "abcdefghijklmnopqrstuvwxyz";
		String upper_Character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String Digit = "0123456789";
		String Symbol = "!@#$&^%><?~:";
		char option;
		do 
		{  
			System.out.println("Enter the length of the password: ");
			length = word.nextInt();
			if(length < 6 )
			{
				System.out.println("Password should be greater than 6");
				System.out.println("Try again!, Program Terminated.");
				System.exit(0);;
			}
			if(length > 20) 
			{
				System.out.println("Password should be lesser than 20");
				System.out.println("Try again!, Program Terminated.");
				System.exit(0);
			}
			System.out.println(" ***** Options ***** ");
			System.out.println("1: Alpha-Number"); 
			System.out.println("2: Alphasymbol");
			System.out.println("3: Numbers and Symbol");
			System.out.println("4: Alpha-Numeric");
			System.out.println("Choose your option(1 - 4): ");
			int choice = word.nextInt();
			Random random = new Random();
			switch(choice) 
			{
				case 1: System.out.println("Alpha-Number passwords"); //Mixed of alphabets and Numbers password
						String alphanumeric = lower_Character + upper_Character + Digit;
						StringBuilder pw = new StringBuilder();
						for(int i = 0; i < length; i++) 
						{
						    char passwords = (char) random.nextInt(alphanumeric.length());// Explicit Type casting 
						    pw.append(alphanumeric.charAt(passwords));
						}
						System.out.println("Random alphabet and number password: "+pw);
						break;
						      
				case 2: System.out.println("Alpha-Symbol passwords"); //Mixed of alphabets and symbols password
						String alphasymbol = lower_Character + upper_Character + Symbol;
						StringBuilder pw1 = new StringBuilder();
						for(int i = 0; i < length; i++) 
						{
						    char passwords1 = (char) random.nextInt(alphasymbol.length());
						    pw1.append(alphasymbol.charAt(passwords1));
						}
						System.out.println("Random alphabet and symbol password: "+pw1);
						break;
						      
				case 3: System.out.println("Number-Symbol passwords"); //Mixed of number and symbols password
						String numsymbol = Digit + Symbol;
						StringBuilder pw2 = new StringBuilder();
						for(int i = 0; i < length; i++) 
						{
						    char passwords2 = (char) random.nextInt(numsymbol.length());
						    pw2.append(numsymbol.charAt(passwords2));
						}
						System.out.println("Random number and symbol password: "+pw2);
						break;
						      
				case 4: System.out.println("Alphanumeric passwords");//Mixed of alphabets - numbers and symbols password
					    System.out.println("This type of password will be recommend");
						String alphanumsymbol = lower_Character + upper_Character + Digit + Symbol;
						StringBuilder pw3 = new StringBuilder();
						for(int i = 0; i < length; i++) 
						{
						    char passwords3 = (char) random.nextInt(alphanumsymbol.length());
						    pw3.append(alphanumsymbol.charAt(passwords3));
						}
						System.out.println("Random alphanumeric password: "+pw3);
						break; 
						      
				default: System.out.println("Enter the correct option");
						         break;
			}
					
			if(length >= 6 && length <= 7)  //Checking the strength of the passwords based on the length
			{
				System.out.println("Weak length of password");
			}
			else if(length <= 15 ) 
			{
				System.out.println("Medium length of password");
			}
			else 
			{
				System.out.println("Strong length of password");
			}
						  
		    System.out.println("Do you want to continue (yes or no)?: ");
			option = word.next().charAt(0);
		
		}while(option == 'Y' || option == 'y'); 
		
		word.close();				
	    return null;
	}
	
	public static void main(String[] args) 
	{
		System.out.println("*--------- RANDOM PASSWORD GENERATOR ---------*");
		
		int length = 0;
		generatePassword(length);
	}
}
